// App.js
import React, { useState, useEffect } from 'react';
import { PublicClientApplication, InteractionRequiredAuthError } from '@azure/msal-browser';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

const msalConfig = {
  auth: {
    clientId: "YOUR_CLIENT_ID", // Replace with your Azure AD app registration client ID
    authority: "https://login.microsoftonline.com/YOUR_TENANT_ID", // Replace with your tenant ID
    redirectUri: "http://localhost:3000"
  }
};

const msalInstance = new PublicClientApplication(msalConfig);

const App = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState(null);

  const courses = [
    {
      id: 1,
      name: "Web Development Fundamentals",
      description: "Learn HTML, CSS, and JavaScript basics",
      duration: "12 weeks"
    },
    {
      id: 2,
      name: "Cloud Computing with Azure",
      description: "Master Azure services and cloud concepts",
      duration: "10 weeks"
    },
    {
      id: 3,
      name: "Data Science Essentials",
      description: "Introduction to data analysis and machine learning",
      duration: "14 weeks"
    }
  ];

  useEffect(() => {
    const accounts = msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      setUser(accounts[0]);
    }
  }, []);

  const login = async () => {
    try {
      const loginResponse = await msalInstance.loginPopup({
        scopes: ["user.read"]
      });
      setUser(loginResponse.account);
    } catch (err) {
      setError("Login failed. Please try again.");
      console.error(err);
    }
  };

  const logout = () => {
    msalInstance.logout();
    setUser(null);
    setSelectedCourse(null);
  };

  const enrollCourse = (course) => {
    setSelectedCourse(course);
    // Here you would typically make an API call to your backend to record the enrollment
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <Card className="w-96">
          <CardHeader>
            <h1 className="text-2xl font-bold text-center">Course Enrollment Portal</h1>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={login}
              className="w-full"
            >
              Login with Microsoft Account
            </Button>
            {error && (
              <Alert className="mt-4" variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Course Enrollment Portal</h1>
          <div className="flex items-center gap-4">
            <span>Welcome, {user.name}</span>
            <Button variant="outline" onClick={logout}>Logout</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="h-full">
              <CardHeader>
                <h2 className="text-xl font-semibold">{course.name}</h2>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{course.description}</p>
                <p className="text-sm text-gray-600 mb-4">Duration: {course.duration}</p>
                <Button
                  onClick={() => enrollCourse(course)}
                  disabled={selectedCourse?.id === course.id}
                  className="w-full"
                >
                  {selectedCourse?.id === course.id ? 'Enrolled' : 'Enroll Now'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {selectedCourse && (
          <Alert className="mt-8">
            <AlertDescription>
              Successfully enrolled in {selectedCourse.name}! You will receive confirmation details via email.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
};

export default App;